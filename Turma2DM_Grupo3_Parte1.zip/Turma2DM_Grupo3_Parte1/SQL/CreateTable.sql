-- ** eliminar tabelas se existentes **
-- CASCADE CONSTRAINTS para eliminar as restri��es de integridade das chaves prim�rias e chaves �nicas
-- PURGE elimina a tabela da base de dados e da "reciclagem"
DROP TABLE Quarto  CASCADE CONSTRAINTS PURGE;
DROP TABLE Andar       CASCADE CONSTRAINTS PURGE;
DROP TABLE Consumo     CASCADE CONSTRAINTS PURGE;
DROP TABLE Epoca  CASCADE CONSTRAINTS PURGE;
DROP TABLE Reserva       CASCADE CONSTRAINTS PURGE;
DROP TABLE Cliente     CASCADE CONSTRAINTS PURGE;
DROP TABLE Camareira_Consumo  CASCADE CONSTRAINTS PURGE;
DROP TABLE Fatura       CASCADE CONSTRAINTS PURGE;
DROP TABLE Funcionario     CASCADE CONSTRAINTS PURGE;
DROP TABLE FuncionarioRececao  CASCADE CONSTRAINTS PURGE;
DROP TABLE FuncionarioRestaurante       CASCADE CONSTRAINTS PURGE;
DROP TABLE Camareira     CASCADE CONSTRAINTS PURGE;
DROP TABLE Intervencao  CASCADE CONSTRAINTS PURGE;
DROP TABLE FuncionarioManutencao       CASCADE CONSTRAINTS PURGE;
DROP TABLE Manutencao     CASCADE CONSTRAINTS PURGE;
DROP TABLE Limpeza  CASCADE CONSTRAINTS PURGE;


CREATE TABLE Quarto(
  numQuarto 	    INTEGER 	CONSTRAINT pknumQuarto     PRIMARY KEY,
  AndarNumeroAndar  INTEGER     CONSTRAINT nnAndarNumeroAndar   NOT NULL,
  lotacaoQuarto     INTEGER     CONSTRAINT nnLotacaoQuarto NOT NULL,
  tipoQuarto        VARCHAR(20)     CONSTRAINT nnTipoQuarto NOT NULL,
  estadoOcupacao    VARCHAR(20)     CONSTRAINT nnEstadoOcupacao NOT NULL
);


CREATE TABLE Andar(
 numeroAndar        INTEGER     CONSTRAINT pkNumeroAndar    PRIMARY KEY,
 nomeAndar          VARCHAR(30)     CONSTRAINT nnNomeAndar    NOT NULL
);

CREATE TABLE Consumo(
 numIdentificacao        INTEGER     CONSTRAINT pkNumIdentificacao    PRIMARY KEY,
 dataAbertura            TIMESTAMP     CONSTRAINT nnDataAbertura    NOT NULL,
 ReservaCodReserva      INTEGER  CONSTRAINT nnReservaCodReserva NOT NULL
);

CREATE TABLE Epoca(
 epocaAno        VARCHAR(20)     CONSTRAINT pkEpocaAno    PRIMARY KEY,
 dataInicio      date     CONSTRAINT nnDataInicio    NOT NULL,
 dataFim         date    CONSTRAINT nnDataFim    NOT NULL
);

CREATE TABLE Reserva(
 codReserva     integer     CONSTRAINT pkCodigoReserva  PRIMARY KEY,
 ClienteNIF     integer     CONSTRAINT nnClienteNIF NOT NULL,
 QuartoNumQuarto    integer CONSTRAINT nnQuartoNumQuarto  NOT NULL,
 EpocaEpocaAno  varchar(20) CONSTRAINT nnEpocaEpocaAno NOT NULL,
 estado         varchar(20)     CONSTRAINT nnEstado  NOT NULL,
 dataEntrada    TIMESTAMP     CONSTRAINT nnDataEntrada    NOT NULL,
 dataSaida      date    CONSTRAINT nnDataSaida    NOT NULL,
 numPessoas     integer     CONSTRAINT nnNumPessoas NOT NULL,
 precoReserva   integer     CONSTRAINT nnPrecoReserva NOT NULL,
 FaturaIdFatura integer     
);

CREATE TABLE Cliente(
 nif        integer         CONSTRAINT pkNif  PRIMARY KEY  CONSTRAINT ckNIF  CHECK(REGEXP_LIKE(nif, '^\d{9}$')),
 nome       varchar(50)     CONSTRAINT nnNome  NOT NULL,
 email      varchar(50)     CONSTRAINT nnEmail  NOT NULL,
 telefone   integer         CONSTRAINT nnTelefone NOT NULL,
 localidade varchar(100)     CONSTRAINT nnLocalidade NOT NULL,
 concelho   varchar(100)     CONSTRAINT nnConcelho NOT NULL
);

CREATE TABLE Fatura(
 idFatura           integer         CONSTRAINT pkIDFatura  PRIMARY KEY,
 valorPagar         integer         CONSTRAINT nnValorPagar NOT NULL,
 metodoPagamento    varchar(20)     CONSTRAINT nnMetodoPagamento NOT NULL 
);

CREATE TABLE Funcionario(
 nif       integer           CONSTRAINT pknifFuncionario  PRIMARY KEY  CONSTRAINT cknifFuncionario   CHECK(REGEXP_LIKE(nif, '^\d{9}$')),
 nome       varchar(50)     CONSTRAINT nnNOMEFuncionario   NOT NULL,
 morada     varchar(50)     CONSTRAINT nnMorada   NOT NULL,
 email      varchar(50)     CONSTRAINT nnEmailFuncionario   NOT NULL,
 telefone   integer         CONSTRAINT nnTelefoneFuncionario   NOT NULL
);


CREATE TABLE Intervencao (
	idIntervencao            INTEGER    CONSTRAINT pkIntervencaoIdIntervencao           PRIMARY KEY,
	tipoIntervencao          VARCHAR(40)                     CONSTRAINT nnIntervencaoTipo                  NOT NULL,
    QuartoNumQuarto         integer                              CONSTRAINT nnQuartoNumQuartoIntervencao  NOT NULL,
	estadoIntervencao			        VARCHAR(40)                     CONSTRAINT nnIntervencaoEstadoIntervencao                 NOT NULL,
	dataIntervencao			        TIMESTAMP                     CONSTRAINT nnIntervencaoData                 NOT NULL
);

CREATE TABLE FuncionarioRestaurante (
	FuncionarioRestaurantenif            INTEGER   CONSTRAINT pkFuncionarioRestauranteNif           PRIMARY KEY
);


CREATE TABLE FuncionarioManutencao (
	funcionarionif            INTEGER  CONSTRAINT pkFuncionarioManutencaoFuncionarioNif           PRIMARY KEY,
	telefoneServico         INTEGER                    CONSTRAINT nnTelefoneServico                NOT NULL,
	nomeResponsavel		VARCHAR(40),                     
	FuncionarioManutencaoFuncionarionif			INTEGER                                 
);


CREATE TABLE Camareira (
	Funcionarionif            INTEGER CONSTRAINT pkCamareiraFuncionarioNif           PRIMARY KEY
);

CREATE TABLE Limpeza (
	IntervencaoidIntervencaoLimpeza            INTEGER   CONSTRAINT pkLimpezaIntervencaoidIntervencao             PRIMARY KEY,
	CamareiraFuncionarionif			INTEGER                     CONSTRAINT nnLimpezaCamareiraFuncionarioFuncionarionif                   NOT NULL
						CONSTRAINT ckLimpezaCamareiraFuncionarioFuncionarionif           CHECK(REGEXP_LIKE(CamareiraFuncionarionif, '^\d{9}$'))	
);


CREATE TABLE Manutencao (
	IntervencaoidIntervencaoManutencao            INTEGER    CONSTRAINT pkManutencaoIntervencaoidIntervencao             PRIMARY KEY,
	FuncionarioManutencaoFuncionarionif			INTEGER                     CONSTRAINT nnManutencaoFuncionarioManutencaoFuncionarionif                   NOT NULL
						CONSTRAINT ckManutencaoFuncionarioManutencaoFuncionarionif           CHECK(REGEXP_LIKE(FuncionarioManutencaoFuncionarionif, '^\d{9}$')),
    tipoReparacao       varchar(255)     CONSTRAINT nnTipoReparacao              NOT NULL    
);

CREATE TABLE Camareira_Consumo (
	ConsumonumIdentificacao            INTEGER                  CONSTRAINT nnCamareiraConsumoConsumonumIdentificacao           NOT NULL,
	CamareiraFuncionarionif			INTEGER                     CONSTRAINT nnCamareiraFuncionarioFuncionarionif                   NOT NULL,
    artigo                          varchar(20)                 CONSTRAINT nnArtigo                   NOT NULL,
    precoArtigo                      integer                    CONSTRAINT nnPrecoArtigo                   NOT NULL,
    dataRegisto                     TIMESTAMP                   CONSTRAINT nnDataRegisto                   NOT NULL,
    CONSTRAINT pkArtigosConsumo PRIMARY KEY(ConsumonumIdentificacao, CamareiraFuncionarionif, artigo, dataRegisto)
);


CREATE TABLE FuncionarioRececao (
	Funcionarionif            INTEGER   CONSTRAINT pkFuncionarioRececaoNif           PRIMARY KEY
);


ALTER TABLE Quarto ADD CONSTRAINT fkQuartoAndarNumeroAndar FOREIGN KEY (AndarNumeroAndar) REFERENCES Andar(numeroAndar);

ALTER TABLE Consumo ADD CONSTRAINT fkReservaCodReserva FOREIGN KEY (ReservaCodReserva) REFERENCES Reserva(codReserva);

ALTER TABLE Camareira_Consumo ADD CONSTRAINT fkConsumonumIdentificacao FOREIGN KEY (ConsumonumIdentificacao) REFERENCES Consumo(numIdentificacao);
ALTER TABLE Camareira_Consumo ADD CONSTRAINT fkCamareiraFuncionarionif FOREIGN KEY (CamareiraFuncionarionif) REFERENCES Camareira(funcionarionif);
	

ALTER TABLE Reserva ADD CONSTRAINT fkclienteNIF FOREIGN KEY (ClienteNIF) REFERENCES Cliente(nif);
ALTER TABLE Reserva ADD CONSTRAINT fkQuartoNumQuarto FOREIGN KEY (QuartoNumQuarto) REFERENCES Quarto(numQuarto);
ALTER TABLE Reserva ADD CONSTRAINT fkEpocaEpocaAno FOREIGN KEY (EpocaEpocaAno) REFERENCES Epoca(epocaAno);
ALTER TABLE Reserva ADD CONSTRAINT fkFaturaIdFatura FOREIGN KEY (FaturaIdFatura) REFERENCES Fatura(idFatura);


ALTER TABLE FuncionarioRececao ADD CONSTRAINT fkalterFuncionarioRececaonif FOREIGN KEY (Funcionarionif) REFERENCES Funcionario(nif);

ALTER TABLE FuncionarioRestaurante ADD CONSTRAINT fkalterFuncionarioRestaurantenif FOREIGN KEY (FuncionarioRestaurantenif) REFERENCES Funcionario(nif);

ALTER TABLE Camareira ADD CONSTRAINT fkalterCamareiranif FOREIGN KEY (Funcionarionif) REFERENCES Funcionario(nif);


ALTER TABLE FuncionarioManutencao ADD CONSTRAINT fkalterFuncionarioManutencaonif FOREIGN KEY (Funcionarionif) REFERENCES Funcionario(nif);
ALTER TABLE FuncionarioManutencao ADD CONSTRAINT fkFuncionarioManutencaoFuncionarionif FOREIGN KEY (FuncionarioManutencaoFuncionarionif) REFERENCES FuncionarioManutencao(Funcionarionif);


ALTER TABLE Intervencao ADD CONSTRAINT fkalterQuartoNumQuarto FOREIGN KEY (QuartoNumQuarto) REFERENCES Quarto(numQuarto);


ALTER TABLE Manutencao ADD CONSTRAINT fkalterIntervencaoidIntervencao FOREIGN KEY (IntervencaoidIntervencaoManutencao) REFERENCES Intervencao(idIntervencao);
ALTER TABLE Manutencao ADD CONSTRAINT fkalterFuncionarioManutencaoFuncionarionif FOREIGN KEY (FuncionarioManutencaoFuncionarionif) REFERENCES FuncionarioManutencao(Funcionarionif);

ALTER TABLE Limpeza ADD CONSTRAINT fkalterIntervencaoidIntervencaoLimpeza FOREIGN KEY (IntervencaoidIntervencaoLimpeza) REFERENCES Intervencao(idIntervencao);
ALTER TABLE Limpeza ADD CONSTRAINT fkalterCamareiraFuncionarionif FOREIGN KEY (CamareiraFuncionarionif) REFERENCES Camareira(Funcionarionif);










