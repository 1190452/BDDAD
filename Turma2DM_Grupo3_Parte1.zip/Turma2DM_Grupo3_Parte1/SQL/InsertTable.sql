-- ** tabela Andar **

INSERT INTO Andar (numeroAndar, nomeAndar) VALUES (120,'Lappeenranta'); 
INSERT INTO Andar (numeroAndar, nomeAndar) VALUES (130,'Turku'); 
INSERT INTO Andar (numeroAndar, nomeAndar) VALUES (140, 'Helsinquia'); 

-- ** tabela Quarto **

INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (1, 120, 2, 'Suite', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (2, 120, 2, 'Suite', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (3, 120, 2, 'Suite', 'livre'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (4, 120, 2, 'Suite', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (5, 120, 2, 'Suite', 'livre'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (6, 120, 2, 'Suite', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (7, 120, 2, 'Suite', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (8, 120, 2, 'Suite', 'livre'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (9, 120, 2, 'Suite', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (10, 120, 2, 'Suite', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (11, 120, 1, 'Single', 'livre'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (12, 120, 1, 'Single', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (13, 120, 1, 'Single', 'livre'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (14, 120, 1, 'Single', 'livre'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (15, 120, 1, 'Single', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (16, 120, 1, 'Single', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (17, 120, 1, 'Single', 'livre'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (18, 120, 1, 'Single', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (19, 120, 1, 'Single', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (20, 120, 1, 'Single', 'livre'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (21, 120, 2, 'Twin', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (22, 120, 2, 'Twin', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (23, 120, 2, 'Twin', 'livre'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (24, 120, 2, 'Twin', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (25, 120, 2, 'Twin', 'livre'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (26, 120, 2, 'Twin', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (27, 120, 2, 'Twin', 'livre'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (28, 120, 2, 'Twin', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (29, 120, 2, 'Twin', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (30, 120, 2, 'Twin', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (31, 120, 3, 'Superior', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (32, 120, 3, 'Superior', 'livre'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (33, 120, 3, 'Superior', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (34, 120, 3, 'Superior', 'livre'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (35, 120, 3, 'Superior', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (36, 120, 3, 'Superior', 'livre'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (37, 120, 3, 'Superior', 'livre'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (38, 120, 3, 'Superior', 'livre'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (39, 120, 3, 'Superior', 'livre'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (40, 120, 3, 'Superior', 'ocupado'); 

INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (41, 130, 2, 'Suite', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (42, 130, 2, 'Suite', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (43, 130, 2, 'Suite', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (44, 130, 2, 'Suite', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (45, 130, 2, 'Suite', 'livre'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (46, 130, 2, 'Suite', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (47, 130, 2, 'Suite', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (48, 130, 2, 'Suite', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (49, 130, 2, 'Suite', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (50, 130, 2, 'Suite', 'livre'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (51, 130, 1, 'Single', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (52, 130, 1, 'Single', 'ocupado');  
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (53, 130, 1, 'Single', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (54, 130, 1, 'Single', 'ocupado');  
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (55, 130, 1, 'Single', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (56, 130, 1, 'Single', 'ocupado');  
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (57, 130, 1, 'Single', 'livre');  
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (58, 130, 1, 'Single', 'livre'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (59, 130, 1, 'Single', 'ocupado');  
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (60, 130, 1, 'Single', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (61, 130, 2, 'Twin', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (62, 130, 2, 'Twin', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (63, 130, 2, 'Twin', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (64, 130, 2, 'Twin', 'livre'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (65, 130, 2, 'Twin', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (66, 130, 2, 'Twin', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (67, 130, 2, 'Twin', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (68, 130, 2, 'Twin', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (69, 130, 2, 'Twin', 'livre'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (70, 130, 2, 'Twin', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (71, 130, 3, 'Superior', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (72, 130, 3, 'Superior', 'livre'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (73, 130, 3, 'Superior', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (74, 130, 3, 'Superior', 'livre'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (75, 130, 3, 'Superior', 'livre'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (76, 130, 3, 'Superior', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (77, 130, 3, 'Superior', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (78, 130, 3, 'Superior', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (79, 130, 3, 'Superior', 'livre'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (80, 130, 3, 'Superior', 'ocupado'); 

INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (81, 140, 2, 'Suite', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (82, 140, 2, 'Suite', 'livre'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (83, 140, 2, 'Suite', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (84, 140, 2, 'Suite', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (85, 140, 2, 'Suite', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (86, 140, 2, 'Suite', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (87, 140, 2, 'Suite', 'livre'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (88, 140, 2, 'Suite', 'livre'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (89, 140, 2, 'Suite', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (90, 140, 2, 'Suite', 'livre'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (91, 140, 1, 'Single', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (92, 140, 1, 'Single', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (93, 140, 1, 'Single', 'livre'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (94, 140, 1, 'Single', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (95, 140, 1, 'Single', 'livre'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (96, 140, 1, 'Single', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (97, 140, 1, 'Single', 'ocupado');  
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (98, 140, 1, 'Single', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (99, 140, 1, 'Single', 'livre'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (100, 140, 1, 'Single', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (101, 140, 2, 'Twin', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (102, 140, 2, 'Twin', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (103, 140, 2, 'Twin', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (104, 140, 2, 'Twin', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (105, 140, 2, 'Twin', 'livre'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (106, 140, 2, 'Twin', 'livre'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (107, 140, 2, 'Twin', 'livre'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (108, 140, 2, 'Twin', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (109, 140, 2, 'Twin', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (110, 140, 2, 'Twin', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (111, 140, 3, 'Superior', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (112, 140, 3, 'Superior', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (113, 140, 3, 'Superior', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (114, 140, 3, 'Superior', 'livre'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (115, 140, 3, 'Superior', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (116, 140, 3, 'Superior', 'livre'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (117, 140, 3, 'Superior', 'ocupado'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (118, 140, 3, 'Superior', 'livre'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (119, 140, 3, 'Superior', 'livre'); 
INSERT INTO Quarto (numQuarto, AndarNumeroAndar, lotacaoQuarto, tipoQuarto, estadoOcupacao) VALUES (140, 140, 3, 'Superior', 'ocupado'); 

-- ** tabela Epoca **

INSERT INTO Epoca (epocaAno, dataInicio, dataFim) VALUES ('Media', TO_DATE('01-01','mm-dd'), TO_DATE('04-30','mm-dd')); 
INSERT INTO Epoca (epocaAno, dataInicio, dataFim) VALUES ('Alta', TO_DATE('05-01','mm-dd'), TO_DATE('08-31','mm-dd')); 
INSERT INTO Epoca (epocaAno, dataInicio, dataFim) VALUES ('Baixa', TO_DATE('09-01','mm-dd'), TO_DATE('12-31','mm-dd')); 

-- ** tabela Fatura **

INSERT INTO Fatura (idFatura, valorPagar, metodoPagamento) VALUES (1,4500, 'Cartao de Credito'); 
INSERT INTO Fatura (idFatura, valorPagar, metodoPagamento) VALUES (2,1220, 'Cheque'); 
INSERT INTO Fatura (idFatura, valorPagar, metodoPagamento) VALUES (3,2250, 'Cheque'); 
INSERT INTO Fatura (idFatura, valorPagar, metodoPagamento) VALUES (4,1950, 'Cartao de Credito'); 
INSERT INTO Fatura (idFatura, valorPagar, metodoPagamento) VALUES (5,4536, 'Cartao de Credito'); 
INSERT INTO Fatura (idFatura, valorPagar, metodoPagamento) VALUES (6,5435, 'Cartao de Debito'); 
INSERT INTO Fatura (idFatura, valorPagar, metodoPagamento) VALUES (7,8768, 'Cartao de Debito'); 
INSERT INTO Fatura (idFatura, valorPagar, metodoPagamento) VALUES (8,800, 'Cartao de Credito'); 
INSERT INTO Fatura (idFatura, valorPagar, metodoPagamento) VALUES (9,6540, 'Cheque'); 
INSERT INTO Fatura (idFatura, valorPagar, metodoPagamento) VALUES (10,3125, 'Cartao de Debito'); 

-- ** tabela Cliente **
INSERT INTO Cliente (nif, nome, email, telefone, localidade, concelho) VALUES (251323221, 'Nuno Castro', 'nc@gmail.com', 912346754, 'Espinho', 'Espinho'); 
INSERT INTO Cliente (nif, nome, email, telefone, localidade, concelho) VALUES (251546455, 'Bruno Pereira', 'bp@gmail.com', 923777500, 'Gaia', 'Gaia');
INSERT INTO Cliente (nif, nome, email, telefone, localidade, concelho) VALUES (567847633, 'Alexandre Rosa', 'ar@gmail.com', 922543555, 'Brangan�a', 'Bragan�a');
INSERT INTO Cliente (nif, nome, email, telefone, localidade, concelho) VALUES (543535333, 'Brunilda Braga', 'bb@gmail.com', 912898702, 'Valen�a', 'Valen�a');
INSERT INTO Cliente (nif, nome, email, telefone, localidade, concelho) VALUES (675575675, 'Enio Vasconcelos', 'ev@gmail.com', 902313123, 'Lisboa', 'Lisboa');
INSERT INTO Cliente (nif, nome, email, telefone, localidade, concelho) VALUES (763545644, 'Nicolas Otamendi', 'no@gmail.com', 972426424, 'Setubal', 'Setubal');
INSERT INTO Cliente (nif, nome, email, telefone, localidade, concelho) VALUES (765675757, 'Eder Goncalves', 'eg@gmail.com', 915670908, 'Coimbra', 'Coimbra');
INSERT INTO Cliente (nif, nome, email, telefone, localidade, concelho) VALUES (756757575, 'Tania Leite', 'tl@gmail.com', 902921878, 'Tondela', 'Tondela');
INSERT INTO Cliente (nif, nome, email, telefone, localidade, concelho) VALUES (867686868, 'Antonio Vardoso', 'av@gmail.com', 933434222, 'Aveiro', 'Aveiro');
INSERT INTO Cliente (nif, nome, email, telefone, localidade, concelho) VALUES (895735353, 'Heriberto Rosario', 'hr@gmail.com', 913112713, 'Arouca', 'Arouca');
INSERT INTO Cliente (nif, nome, email, telefone, localidade, concelho) VALUES (432424244, 'Anselmo Ralph', 'ar@gmail.com', 932402112, 'Faro', 'Faro');
INSERT INTO Cliente (nif, nome, email, telefone, localidade, concelho) VALUES (643252675, 'Anita Carneiro', 'ac@gmail.com', 912323000, 'Zambujeira do Mar', 'Zambujeira do Mar');
INSERT INTO Cliente (nif, nome, email, telefone, localidade, concelho) VALUES (765524225, 'Badoxa Varela', 'bv@gmail.com', 912313111, 'Vale do Lobo', 'Vale do Lobo');
INSERT INTO Cliente (nif, nome, email, telefone, localidade, concelho) VALUES (312435355, 'Ricardo Antonino', 'ra@gmail.com', 912890876, 'Amadora', 'Amadora');
INSERT INTO Cliente (nif, nome, email, telefone, localidade, concelho) VALUES (654635225, 'Jose Silva', 'js@gmail.com', 912892321, 'Vila Real', 'Vila Real');
INSERT INTO Cliente (nif, nome, email, telefone, localidade, concelho) VALUES (644564525, 'Toy Framboesas', 'tf@gmail.com', 912432110, 'Vila Franca de Xira', 'Vila Franca de Xira');
INSERT INTO Cliente (nif, nome, email, telefone, localidade, concelho) VALUES (134669745, 'Tiago Pereira', 'tp@gmail.com', 901322112, 'Santiago do Cacem', 'Santiago do Cacem');
INSERT INTO Cliente (nif, nome, email, telefone, localidade, concelho) VALUES (143533664, 'Lino Lopes', 'll@gmail.com', 917535123, 'Peniche', 'Peniche');
INSERT INTO Cliente (nif, nome, email, telefone, localidade, concelho) VALUES (534464646, 'Mariano Soares', 'ms@gmail.com', 934322156, 'Troia', 'Troia');
INSERT INTO Cliente (nif, nome, email, telefone, localidade, concelho) VALUES (423536456, 'Seferovic Cone', 'sc@gmail.com', 988745321, 'Cartaxo', 'Cartaxo');
INSERT INTO Cliente (nif, nome, email, telefone, localidade, concelho) VALUES (436474564, 'Adalberto Bento', 'ab@gmail.com', 912111565, 'Oliveira do Hospital', 'Oliveira do Hospital');
INSERT INTO Cliente (nif, nome, email, telefone, localidade, concelho) VALUES (454353535, 'Valentina Coimbra', 'vc@gmail.com', 919003565, 'Vila Real de Santo Antonio', 'Vila Real de Santo Antonio');
INSERT INTO Cliente (nif, nome, email, telefone, localidade, concelho) VALUES (543530095, 'Isaura Passos', 'ip@gmail.com', 912898756, 'Matosinhos', 'Matosinhos');
INSERT INTO Cliente (nif, nome, email, telefone, localidade, concelho) VALUES (534647657, 'Benedito Rosa', 'br@gmail.com', 912898778, 'Barcelos', 'Barcelos');
INSERT INTO Cliente (nif, nome, email, telefone, localidade, concelho) VALUES (538345735, 'Olivier Giroud', 'og@gmail.com', 923013755, 'Sesimbra', 'Sesimbra');

-- ** tabela Reserva **

INSERT INTO Reserva (codReserva, ClienteNIF, QuartoNumQuarto, EpocaEpocaAno, estado, dataEntrada, dataSaida, numPessoas, precoReserva, FaturaIdFatura) 
VALUES (1, 654635225, 81, 'Media', 'finalizada', TO_TIMESTAMP('2020-01-04 13:10:11', 'yyyy-mm-dd hh24:mi:ss'), TO_DATE('2020-01-15','yyyy-mm-dd'), 2, 4000, 1); 
INSERT INTO Reserva (codReserva, ClienteNIF, QuartoNumQuarto, EpocaEpocaAno, estado, dataEntrada, dataSaida, numPessoas, precoReserva, FaturaIdFatura) 
VALUES (2, 543535333, 98, 'Media', 'finalizada', TO_TIMESTAMP('2020-01-01 18:10:11', 'yyyy-mm-dd hh24:mi:ss'), TO_DATE('2020-01-15','yyyy-mm-dd'), 1, 1180, 2); 
INSERT INTO Reserva (codReserva, ClienteNIF, QuartoNumQuarto, EpocaEpocaAno, estado, dataEntrada, dataSaida, numPessoas, precoReserva, FaturaIdFatura) 
VALUES (3, 654635225, 19, 'Media', 'finalizada', TO_TIMESTAMP('2020-02-27 19:10:11', 'yyyy-mm-dd hh24:mi:ss'), TO_DATE('2020-02-28','yyyy-mm-dd'), 1, 650, 8); 
INSERT INTO Reserva (codReserva, ClienteNIF, QuartoNumQuarto, EpocaEpocaAno, estado, dataEntrada, dataSaida, numPessoas, precoReserva, FaturaIdFatura) 
VALUES (4, 423536456, 140, 'Media', 'ativa', TO_TIMESTAMP('2020-03-03 17:24:11', 'yyyy-mm-dd hh24:mi:ss'), TO_DATE('2020-03-25','yyyy-mm-dd'), 3, 5750, null); 
INSERT INTO Reserva (codReserva, ClienteNIF, QuartoNumQuarto, EpocaEpocaAno, estado, dataEntrada, dataSaida, numPessoas, precoReserva, FaturaIdFatura) 
VALUES (5, 538345735, 110, 'Media', 'finalizada', TO_TIMESTAMP('2020-04-04 23:10:11', 'yyyy-mm-dd hh24:mi:ss'), TO_DATE('2020-04-21','yyyy-mm-dd'), 2, 8000, 7); 

INSERT INTO Reserva (codReserva, ClienteNIF, QuartoNumQuarto, EpocaEpocaAno, estado, dataEntrada, dataSaida, numPessoas, precoReserva, FaturaIdFatura) 
VALUES (6, 251323221, 10, 'Baixa', 'finalizada', TO_TIMESTAMP('2020-09-09 09:10:11' , 'yyyy-mm-dd hh24:mi:ss'), TO_DATE('2020-09-15','yyyy-mm-dd'), 2, 2900, 10); 
INSERT INTO Reserva (codReserva, ClienteNIF, QuartoNumQuarto, EpocaEpocaAno, estado, dataEntrada, dataSaida, numPessoas, precoReserva, FaturaIdFatura) 
VALUES (7, 312435355, 40, 'Baixa', 'ativa', TO_TIMESTAMP('2020-12-12 13:10:11', 'yyyy-mm-dd hh24:mi:ss'), TO_DATE('2020-12-14','yyyy-mm-dd'), 3, 2550, null); 
INSERT INTO Reserva (codReserva, ClienteNIF, QuartoNumQuarto, EpocaEpocaAno, estado, dataEntrada, dataSaida, numPessoas, precoReserva, FaturaIdFatura) 
VALUES (8, 644564525, 97, 'Baixa', 'finalizada', TO_TIMESTAMP('2020-10-10 23:15:11', 'yyyy-mm-dd hh24:mi:ss'), TO_DATE('2020-10-27','yyyy-mm-dd'), 1, 1500, 4); 
INSERT INTO Reserva (codReserva, ClienteNIF, QuartoNumQuarto, EpocaEpocaAno, estado, dataEntrada, dataSaida, numPessoas, precoReserva, FaturaIdFatura) 
VALUES (9, 538345735, 108, 'Baixa', 'cancelada', TO_TIMESTAMP('2020-11-13 16:10:11', 'yyyy-mm-dd hh24:mi:ss'), TO_DATE('2020-11-15','yyyy-mm-dd'), 2, 6664, null); 
INSERT INTO Reserva (codReserva, ClienteNIF, QuartoNumQuarto, EpocaEpocaAno, estado, dataEntrada, dataSaida, numPessoas, precoReserva, FaturaIdFatura) 
VALUES (10, 534647657, 77, 'Baixa', 'finalizada', TO_TIMESTAMP('2020-12-17 21:45:11', 'yyyy-mm-dd hh24:mi:ss'), TO_DATE('2020-12-25','yyyy-mm-dd'), 3, 4900, 6); 

INSERT INTO Reserva (codReserva, ClienteNIF, QuartoNumQuarto, EpocaEpocaAno, estado, dataEntrada, dataSaida, numPessoas, precoReserva, FaturaIdFatura) 
VALUES (11, 567847633, 80, 'Alta', 'cancelada', TO_TIMESTAMP('2020-05-10 09:55:11', 'yyyy-mm-dd hh24:mi:ss'), TO_DATE('2020-05-19','yyyy-mm-dd'), 3, 8730, null); 
INSERT INTO Reserva (codReserva, ClienteNIF, QuartoNumQuarto, EpocaEpocaAno, estado, dataEntrada, dataSaida, numPessoas, precoReserva, FaturaIdFatura) 
VALUES (12, 675575675, 81, 'Alta', 'finalizada', TO_TIMESTAMP('2020-06-28 12:30:59', 'yyyy-mm-dd hh24:mi:ss'), TO_DATE('2020-06-30','yyyy-mm-dd'), 2, 1897, 3); 
INSERT INTO Reserva (codReserva, ClienteNIF, QuartoNumQuarto, EpocaEpocaAno, estado, dataEntrada, dataSaida, numPessoas, precoReserva, FaturaIdFatura) 
VALUES (13, 432424244, 31, 'Alta', 'finalizada', TO_TIMESTAMP('2020-07-07 19:37:11', 'yyyy-mm-dd hh24:mi:ss'), TO_DATE('2020-07-27','yyyy-mm-dd'), 3, 4000, 5); 
INSERT INTO Reserva (codReserva, ClienteNIF, QuartoNumQuarto, EpocaEpocaAno, estado, dataEntrada, dataSaida, numPessoas, precoReserva, FaturaIdFatura) 
VALUES (14, 143533664, 19, 'Alta', 'ativa', TO_TIMESTAMP('2020-08-04 13:10:11', 'yyyy-mm-dd hh24:mi:ss'), TO_DATE('2020-08-21','yyyy-mm-dd'), 3, 19455, null); 
INSERT INTO Reserva (codReserva, ClienteNIF, QuartoNumQuarto, EpocaEpocaAno, estado, dataEntrada, dataSaida, numPessoas, precoReserva, FaturaIdFatura) 
VALUES (15, 312435355, 63, 'Alta', 'finalizada', TO_TIMESTAMP('2020-08-13 11:10:11', 'yyyy-mm-dd hh24:mi:ss'), TO_DATE('2020-08-19','yyyy-mm-dd'), 2, 4788, 9); 
INSERT INTO Reserva (codReserva, ClienteNIF, QuartoNumQuarto, EpocaEpocaAno, estado, dataEntrada, dataSaida, numPessoas, precoReserva, FaturaIdFatura) 
VALUES (16, 312435355, 81, 'Alta', 'ativa', TO_TIMESTAMP('2020-08-13 11:10:11', 'yyyy-mm-dd hh24:mi:ss'), TO_DATE('2020-08-19','yyyy-mm-dd'), 2, 5463, null); 
INSERT INTO Reserva (codReserva, ClienteNIF, QuartoNumQuarto, EpocaEpocaAno, estado, dataEntrada, dataSaida, numPessoas, precoReserva, FaturaIdFatura) 
VALUES (17, 654635225, 19, 'Alta', 'ativa', TO_TIMESTAMP('2020-06-27 19:10:11', 'yyyy-mm-dd hh24:mi:ss'), TO_DATE('2020-06-28','yyyy-mm-dd'), 1, 788, null); 

 


-- ** tabela Consumo **
insert into Consumo (numIdentificacao, dataAbertura, ReservaCodReserva)VALUES(1,TO_TIMESTAMP('2020-01-05 11:00:00', 'yyyy-mm-dd hh24:mi:ss'), 1);
insert into Consumo (numIdentificacao, dataAbertura, ReservaCodReserva)VALUES(2,TO_TIMESTAMP('2020-01-02 13:12:34', 'yyyy-mm-dd hh24:mi:ss'), 2);
insert into Consumo (numIdentificacao, dataAbertura, ReservaCodReserva)VALUES(3,TO_TIMESTAMP('2020-02-28 14:53:11', 'yyyy-mm-dd hh24:mi:ss'), 3);
insert into Consumo (numIdentificacao, dataAbertura, ReservaCodReserva)VALUES(4,TO_TIMESTAMP('2020-03-04 17:24:11', 'yyyy-mm-dd hh24:mi:ss'), 4);
insert into Consumo (numIdentificacao, dataAbertura, ReservaCodReserva)VALUES(5,TO_TIMESTAMP('2020-04-04 15:45:11', 'yyyy-mm-dd hh24:mi:ss'), 5);

insert into Consumo (numIdentificacao, dataAbertura, ReservaCodReserva)VALUES(6,TO_TIMESTAMP('2020-09-11 21:26:47', 'yyyy-mm-dd hh24:mi:ss'), 6);
insert into Consumo (numIdentificacao, dataAbertura, ReservaCodReserva)VALUES(7,TO_TIMESTAMP('2020-12-13 21:16:11', 'yyyy-mm-dd hh24:mi:ss'), 7);
insert into Consumo (numIdentificacao, dataAbertura, ReservaCodReserva)VALUES(8,TO_TIMESTAMP('2020-10-18 18:22:14', 'yyyy-mm-dd hh24:mi:ss'), 8);
insert into Consumo (numIdentificacao, dataAbertura, ReservaCodReserva)VALUES(9,TO_TIMESTAMP('2020-11-14 23:55:11', 'yyyy-mm-dd hh24:mi:ss'), 9);
insert into Consumo (numIdentificacao, dataAbertura, ReservaCodReserva)VALUES(10,TO_TIMESTAMP('2020-12-17 19:45:25', 'yyyy-mm-dd hh24:mi:ss'), 10);

insert into Consumo (numIdentificacao, dataAbertura, ReservaCodReserva)VALUES(11,TO_TIMESTAMP('2020-05-15 12:36:11', 'yyyy-mm-dd hh24:mi:ss'), 11);
insert into Consumo (numIdentificacao, dataAbertura, ReservaCodReserva)VALUES(12,TO_TIMESTAMP('2020-06-29 15:16:17', 'yyyy-mm-dd hh24:mi:ss'), 12);
insert into Consumo (numIdentificacao, dataAbertura, ReservaCodReserva)VALUES(13,TO_TIMESTAMP('2020-07-19 08:45:11', 'yyyy-mm-dd hh24:mi:ss'), 13);
insert into Consumo (numIdentificacao, dataAbertura, ReservaCodReserva)VALUES(14,TO_TIMESTAMP('2020-08-18 13:10:11', 'yyyy-mm-dd hh24:mi:ss'), 14);
insert into Consumo (numIdentificacao, dataAbertura, ReservaCodReserva)VALUES(15,TO_TIMESTAMP('2020-08-14 13:10:11', 'yyyy-mm-dd hh24:mi:ss'), 15);
insert into Consumo (numIdentificacao, dataAbertura, ReservaCodReserva)VALUES(16,TO_TIMESTAMP('2020-08-15 13:10:11', 'yyyy-mm-dd hh24:mi:ss'), 16);
insert into Consumo (numIdentificacao, dataAbertura, ReservaCodReserva)VALUES(17,TO_TIMESTAMP('2020-08-28 13:10:11', 'yyyy-mm-dd hh24:mi:ss'), 17);

-- ** tabela Funcion�rio **
insert into Funcionario(nif, nome, morada, email, telefone) VALUES (145854793, 'Adalberto Barbosa', 'Rua do Hotel', 'abarbosa@hotmail.com', 252698103);
insert into Funcionario(nif, nome, morada, email, telefone) VALUES (145854794, 'Joaquim Barbosa', 'Rua do Toural', 'jbarbosa@hotmail.com', 252698104);


insert into Funcionario(nif, nome, morada, email, telefone) VALUES (236901403, 'Marciano Cruz', 'Rua do Port�o', 'mcruz@hotmail.com', 252147369);
insert into Funcionario(nif, nome, morada, email, telefone) VALUES (236901404, 'Almir Cruz', 'Rua do Quarto', 'acruz@hotmail.com', 252147368);

insert into Funcionario(nif, nome, morada, email, telefone) VALUES (205314000, 'Marlene Menezes', 'Rua da Macacoa', 'mmenezes@hotmail.com', 253111222);
insert into Funcionario(nif, nome, morada, email, telefone) VALUES (205314001, 'Zita Menezes', 'Rua da Est�tua', 'zmenezes@hotmail.com', 253111333);
insert into Funcionario(nif, nome, morada, email, telefone) VALUES (205314002, 'Nicole Menezes', 'Rua do Cacetete', 'nmenezes@hotmail.com', 253111444);
insert into Funcionario(nif, nome, morada, email, telefone) VALUES (205314003, 'Olga Menezes', 'Rua da Liberdade', 'omenezes@hotmail.com', 253111555);
insert into Funcionario(nif, nome, morada, email, telefone) VALUES (205314004, 'Efig�nia Menezes', 'Rua Jos� Fidalgo', 'emenezes@hotmail.com', 253111666);

insert into Funcionario(nif, nome, morada, email, telefone) VALUES (253699888, 'Edgar Siqueira', 'Rua Bacalhau � Br�s', 'esiqueira@hotmail.com', 255333666);
insert into Funcionario(nif, nome, morada, email, telefone) VALUES (253699889, 'Alcides Siqueira', 'Rua Feijoada � Transmontana', 'asiqueira@hotmail.com', 255333777);
insert into Funcionario(nif, nome, morada, email, telefone) VALUES (253699810, 'Paulino Siqueira', 'Rua Bacalhau � Z� do Pipo', 'psiqueira@hotmail.com', 255333888);
insert into Funcionario(nif, nome, morada, email, telefone) VALUES (253699811, 'Mauro Siqueira', 'Rua do Z� Povinho', 'msiqueira@hotmail.com', 255333999);

-- ** tabela Camareira **
insert into Camareira(Funcionarionif) VALUES(205314000);
insert into Camareira(Funcionarionif) VALUES(205314001);
insert into Camareira(Funcionarionif) VALUES(205314002);
insert into Camareira(Funcionarionif) VALUES(205314003);
insert into Camareira(Funcionarionif) VALUES(205314004);

-- ** tabela Camareira_Consumo **
insert into Camareira_Consumo (ConsumonumIdentificacao, CamareiraFuncionarionif, artigo, precoArtigo, dataRegisto)VALUES(1,205314000,'Bebida', 3, TO_TIMESTAMP('2020-01-05 11:00:00', 'yyyy-mm-dd hh24:mi:ss'));
insert into Camareira_Consumo (ConsumonumIdentificacao, CamareiraFuncionarionif, artigo, precoArtigo, dataRegisto)VALUES(1,205314000,'Snack', 6, TO_TIMESTAMP('2020-01-06 11:17:00', 'yyyy-mm-dd hh24:mi:ss'));
insert into Camareira_Consumo (ConsumonumIdentificacao, CamareiraFuncionarionif, artigo, precoArtigo, dataRegisto)VALUES(1,205314000,'Snack', 7, TO_TIMESTAMP('2020-01-06 11:18:00', 'yyyy-mm-dd hh24:mi:ss'));

insert into Camareira_Consumo (ConsumonumIdentificacao, CamareiraFuncionarionif, artigo, precoArtigo, dataRegisto)VALUES(2,205314000,'Bebida', 3, TO_TIMESTAMP('2020-01-02 13:12:34', 'yyyy-mm-dd hh24:mi:ss'));
insert into Camareira_Consumo (ConsumonumIdentificacao, CamareiraFuncionarionif, artigo, precoArtigo, dataRegisto)VALUES(2,205314000,'Bebida', 18, TO_TIMESTAMP('2020-01-07 11:17:00', 'yyyy-mm-dd hh24:mi:ss'));
insert into Camareira_Consumo (ConsumonumIdentificacao, CamareiraFuncionarionif, artigo, precoArtigo, dataRegisto)VALUES(2,205314000,'Snack', 7, TO_TIMESTAMP('2020-01-12 16:17:00', 'yyyy-mm-dd hh24:mi:ss'));
insert into Camareira_Consumo (ConsumonumIdentificacao, CamareiraFuncionarionif, artigo, precoArtigo, dataRegisto)VALUES(2,205314000,'Snack', 4, TO_TIMESTAMP('2020-01-14 10:24:00', 'yyyy-mm-dd hh24:mi:ss'));

insert into Camareira_Consumo (ConsumonumIdentificacao, CamareiraFuncionarionif, artigo, precoArtigo, dataRegisto)VALUES(3,205314000,'Snack', 7, TO_TIMESTAMP('2020-02-28 14:53:11', 'yyyy-mm-dd hh24:mi:ss'));
insert into Camareira_Consumo (ConsumonumIdentificacao, CamareiraFuncionarionif, artigo, precoArtigo, dataRegisto)VALUES(3,205314000,'Bebida', 4, TO_TIMESTAMP('2020-02-28 14:54:00', 'yyyy-mm-dd hh24:mi:ss'));

insert into Camareira_Consumo (ConsumonumIdentificacao, CamareiraFuncionarionif, artigo, precoArtigo, dataRegisto)VALUES(4,205314000,'Arroz', 7, TO_TIMESTAMP('2020-03-04 17:24:11', 'yyyy-mm-dd hh24:mi:ss'));
insert into Camareira_Consumo (ConsumonumIdentificacao, CamareiraFuncionarionif, artigo, precoArtigo, dataRegisto)VALUES(4,205314000,'Bebida', 4, TO_TIMESTAMP('2020-03-09 09:07:00', 'yyyy-mm-dd hh24:mi:ss'));
insert into Camareira_Consumo (ConsumonumIdentificacao, CamareiraFuncionarionif, artigo, precoArtigo, dataRegisto)VALUES(4,205314000,'Bebida', 60, TO_TIMESTAMP('2020-03-15 16:32:00', 'yyyy-mm-dd hh24:mi:ss'));
insert into Camareira_Consumo (ConsumonumIdentificacao, CamareiraFuncionarionif, artigo, precoArtigo, dataRegisto)VALUES(4,205314000,'Snack', 4, TO_TIMESTAMP('2020-03-23 10:56:00', 'yyyy-mm-dd hh24:mi:ss'));

insert into Camareira_Consumo (ConsumonumIdentificacao, CamareiraFuncionarionif, artigo, precoArtigo, dataRegisto)VALUES(5,205314000,'Bebida', 5, TO_TIMESTAMP('2020-04-04 15:45:11', 'yyyy-mm-dd hh24:mi:ss'));
insert into Camareira_Consumo (ConsumonumIdentificacao, CamareiraFuncionarionif, artigo, precoArtigo, dataRegisto)VALUES(5,205314000,'Bebida', 3, TO_TIMESTAMP('2020-04-14 14:25:04', 'yyyy-mm-dd hh24:mi:ss'));
insert into Camareira_Consumo (ConsumonumIdentificacao, CamareiraFuncionarionif, artigo, precoArtigo, dataRegisto)VALUES(5,205314000,'Snack', 3, TO_TIMESTAMP('2020-04-17 23:10:24', 'yyyy-mm-dd hh24:mi:ss'));
insert into Camareira_Consumo (ConsumonumIdentificacao, CamareiraFuncionarionif, artigo, precoArtigo, dataRegisto)VALUES(5,205314000,'Bebida', 4, TO_TIMESTAMP('2020-04-21 05:24:57', 'yyyy-mm-dd hh24:mi:ss'));

insert into Camareira_Consumo (ConsumonumIdentificacao, CamareiraFuncionarionif, artigo, precoArtigo, dataRegisto)VALUES(6,205314000,'Bebida', 4, TO_TIMESTAMP('2020-09-11 21:26:47', 'yyyy-mm-dd hh24:mi:ss'));
insert into Camareira_Consumo (ConsumonumIdentificacao, CamareiraFuncionarionif, artigo, precoArtigo, dataRegisto)VALUES(6,205314000,'Snack', 5, TO_TIMESTAMP('2020-09-13 23:42:45', 'yyyy-mm-dd hh24:mi:ss'));

insert into Camareira_Consumo (ConsumonumIdentificacao, CamareiraFuncionarionif, artigo, precoArtigo, dataRegisto)VALUES(7,205314000,'Snack', 7, TO_TIMESTAMP('2020-12-13 21:16:11', 'yyyy-mm-dd hh24:mi:ss'));
insert into Camareira_Consumo (ConsumonumIdentificacao, CamareiraFuncionarionif, artigo, precoArtigo, dataRegisto)VALUES(7,205314000,'Bebida', 55, TO_TIMESTAMP('2020-12-13 21:17:43', 'yyyy-mm-dd hh24:mi:ss'));
insert into Camareira_Consumo (ConsumonumIdentificacao, CamareiraFuncionarionif, artigo, precoArtigo, dataRegisto)VALUES(7,205314000,'Bebida', 200, TO_TIMESTAMP('2020-12-14 10:36:25', 'yyyy-mm-dd hh24:mi:ss'));

insert into Camareira_Consumo (ConsumonumIdentificacao, CamareiraFuncionarionif, artigo, precoArtigo, dataRegisto)VALUES(8,205314000,'Bebida', 5, TO_TIMESTAMP('2020-10-18 18:22:14','yyyy-mm-dd hh24:mi:ss'));
insert into Camareira_Consumo (ConsumonumIdentificacao, CamareiraFuncionarionif, artigo, precoArtigo, dataRegisto)VALUES(8,205314000,'Bebida', 3, TO_TIMESTAMP('2020-10-25 12:54:00', 'yyyy-mm-dd hh24:mi:ss'));

insert into Camareira_Consumo (ConsumonumIdentificacao, CamareiraFuncionarionif, artigo, precoArtigo, dataRegisto)VALUES(9,205314000,'Snack', 6, TO_TIMESTAMP('2020-11-14 23:55:11', 'yyyy-mm-dd hh24:mi:ss'));

insert into Camareira_Consumo (ConsumonumIdentificacao, CamareiraFuncionarionif, artigo, precoArtigo, dataRegisto)VALUES(10,205314000,'Snack', 7, TO_TIMESTAMP('2020-12-17 19:45:25', 'yyyy-mm-dd hh24:mi:ss'));
insert into Camareira_Consumo (ConsumonumIdentificacao, CamareiraFuncionarionif, artigo, precoArtigo, dataRegisto)VALUES(10,205314000,'Bebida', 4, TO_TIMESTAMP('2020-12-21 21:45:54', 'yyyy-mm-dd hh24:mi:ss'));
insert into Camareira_Consumo (ConsumonumIdentificacao, CamareiraFuncionarionif, artigo, precoArtigo, dataRegisto)VALUES(10,205314000,'Bebida', 29, TO_TIMESTAMP('2020-12-24 23:51:51', 'yyyy-mm-dd hh24:mi:ss'));
insert into Camareira_Consumo (ConsumonumIdentificacao, CamareiraFuncionarionif, artigo, precoArtigo, dataRegisto)VALUES(10,205314000,'Snack', 5, TO_TIMESTAMP('2020-12-24 23:52:11', 'yyyy-mm-dd hh24:mi:ss'));

insert into Camareira_Consumo (ConsumonumIdentificacao, CamareiraFuncionarionif, artigo, precoArtigo, dataRegisto)VALUES(11,205314000,'Bebida', 3, TO_TIMESTAMP('2020-05-15 12:36:11', 'yyyy-mm-dd hh24:mi:ss'));
insert into Camareira_Consumo (ConsumonumIdentificacao, CamareiraFuncionarionif, artigo, precoArtigo, dataRegisto)VALUES(11,205314000,'Snack', 5, TO_TIMESTAMP('2020-05-17 18:52:52', 'yyyy-mm-dd hh24:mi:ss'));

insert into Camareira_Consumo (ConsumonumIdentificacao, CamareiraFuncionarionif, artigo, precoArtigo, dataRegisto)VALUES(12,205314000,'Bebida', 5, TO_TIMESTAMP('2020-06-29 15:16:17', 'yyyy-mm-dd hh24:mi:ss'));

insert into Camareira_Consumo (ConsumonumIdentificacao, CamareiraFuncionarionif, artigo, precoArtigo, dataRegisto)VALUES(13,205314000,'Snack', 5, TO_TIMESTAMP('2020-07-19 08:45:11', 'yyyy-mm-dd hh24:mi:ss'));
insert into Camareira_Consumo (ConsumonumIdentificacao, CamareiraFuncionarionif, artigo, precoArtigo, dataRegisto)VALUES(13,205314000,'Bebida', 3, TO_TIMESTAMP('2020-07-25 11:53:22', 'yyyy-mm-dd hh24:mi:ss'));

insert into Camareira_Consumo (ConsumonumIdentificacao, CamareiraFuncionarionif, artigo, precoArtigo, dataRegisto)VALUES(14,205314000,'Snack', 5,TO_TIMESTAMP('2020-08-18 13:10:11', 'yyyy-mm-dd hh24:mi:ss'));
insert into Camareira_Consumo (ConsumonumIdentificacao, CamareiraFuncionarionif, artigo, precoArtigo, dataRegisto)VALUES(14,205314000,'Bebida', 3, TO_TIMESTAMP('2020-08-19 12:54:00', 'yyyy-mm-dd hh24:mi:ss'));

insert into Camareira_Consumo (ConsumonumIdentificacao, CamareiraFuncionarionif, artigo, precoArtigo, dataRegisto)VALUES(15,205314000,'Snack', 5,TO_TIMESTAMP('2020-08-14 13:10:11', 'yyyy-mm-dd hh24:mi:ss'));

insert into Camareira_Consumo (ConsumonumIdentificacao, CamareiraFuncionarionif, artigo, precoArtigo, dataRegisto)VALUES(16,205314000,'Snack', 5,TO_TIMESTAMP('2020-08-15 13:10:11', 'yyyy-mm-dd hh24:mi:ss'));
insert into Camareira_Consumo (ConsumonumIdentificacao, CamareiraFuncionarionif, artigo, precoArtigo, dataRegisto)VALUES(16,205314000,'Bebida', 5,TO_TIMESTAMP('2020-08-16 23:55:11', 'yyyy-mm-dd hh24:mi:ss'));

insert into Camareira_Consumo (ConsumonumIdentificacao, CamareiraFuncionarionif, artigo, precoArtigo, dataRegisto)VALUES(17,205314000,'Arroz', 5,TO_TIMESTAMP('2020-08-28 12:15:44', 'yyyy-mm-dd hh24:mi:ss'));


-- ** tabela FuncionarioRececao **
insert into FuncionarioRececao(Funcionarionif) VALUES (145854793);
insert into FuncionarioRececao(Funcionarionif) VALUES (145854794);

-- ** tabela FuncionarioRestaurante **
insert into FuncionarioRestaurante(FuncionarioRestaurantenif) VALUES (236901403);
insert into FuncionarioRestaurante(FuncionarioRestaurantenif) VALUES (236901404);


-- ** tabela FuncionarioManutencao **
insert into FuncionarioManutencao(funcionarionif, telefoneServico, nomeResponsavel, FuncionarioManutencaoFuncionarionif) VALUES (253699888, 933777888,  null,null); 
insert into FuncionarioManutencao(funcionarionif, telefoneServico, nomeResponsavel, FuncionarioManutencaoFuncionarionif) VALUES (253699889, 933777999, 'Edgar Siqueira',253699888); 
insert into FuncionarioManutencao(funcionarionif, telefoneServico, nomeResponsavel, FuncionarioManutencaoFuncionarionif) VALUES (253699810, 933555333, 'Edgar Siqueira',253699888); 
insert into FuncionarioManutencao(funcionarionif, telefoneServico, nomeResponsavel, FuncionarioManutencaoFuncionarionif) VALUES (253699811, 933101010, 'Edgar Siqueira',253699888); 


-- ** tabela Intervencao **
insert into Intervencao(idIntervencao, tipoIntervencao, QuartoNumQuarto, estadoIntervencao, dataIntervencao)
VALUES(1, 'manutencao', 98, 'concluido', TO_TIMESTAMP('2020-01-28 16:29:00', 'yyyy-mm-dd hh24:mi:ss'));
insert into Intervencao(idIntervencao, tipoIntervencao, QuartoNumQuarto, estadoIntervencao, dataIntervencao)
VALUES(2, 'manutencao', 31, 'concluido', TO_TIMESTAMP('2020-10-20 16:36:00', 'yyyy-mm-dd hh24:mi:ss'));
insert into Intervencao(idIntervencao, tipoIntervencao, QuartoNumQuarto, estadoIntervencao, dataIntervencao)
VALUES(3, 'manutencao', 97, 'concluido', TO_TIMESTAMP('2020-11-15 16:29:00', 'yyyy-mm-dd hh24:mi:ss'));
insert into Intervencao(idIntervencao, tipoIntervencao, QuartoNumQuarto, estadoIntervencao, dataIntervencao)
VALUES(4, 'manutencao', 111, 'pendente', TO_TIMESTAMP('2020-11-16 12:00:00', 'yyyy-mm-dd hh24:mi:ss'));
insert into Intervencao(idIntervencao, tipoIntervencao, QuartoNumQuarto, estadoIntervencao, dataIntervencao)
VALUES(5, 'manutencao', 40, 'pendente', TO_TIMESTAMP('2020-11-19 17:14:00', 'yyyy-mm-dd hh24:mi:ss'));

insert into Intervencao(idIntervencao, tipoIntervencao, QuartoNumQuarto, estadoIntervencao, dataIntervencao)
VALUES(6, 'limpeza', 45, 'pendente', TO_TIMESTAMP('2020-12-22 16:03:00', 'yyyy-mm-dd hh24:mi:ss'));
insert into Intervencao(idIntervencao, tipoIntervencao, QuartoNumQuarto, estadoIntervencao, dataIntervencao)
VALUES(7, 'limpeza', 8, 'concluido', TO_TIMESTAMP('2020-06-21 16:36:00', 'yyyy-mm-dd hh24:mi:ss'));
insert into Intervencao(idIntervencao, tipoIntervencao, QuartoNumQuarto, estadoIntervencao, dataIntervencao)
VALUES(8, 'limpeza', 13, 'concluido', TO_TIMESTAMP('2020-10-03 16:29:00', 'yyyy-mm-dd hh24:mi:ss'));
insert into Intervencao(idIntervencao, tipoIntervencao, QuartoNumQuarto, estadoIntervencao, dataIntervencao)
VALUES(9, 'limpeza', 87, 'concluido', TO_TIMESTAMP('2020-07-30 12:00:00', 'yyyy-mm-dd hh24:mi:ss'));
insert into Intervencao(idIntervencao, tipoIntervencao, QuartoNumQuarto, estadoIntervencao, dataIntervencao)
VALUES(10, 'limpeza', 88, 'concluido', TO_TIMESTAMP('2020-06-25 17:14:00', 'yyyy-mm-dd hh24:mi:ss'));
insert into Intervencao(idIntervencao, tipoIntervencao, QuartoNumQuarto, estadoIntervencao, dataIntervencao)
VALUES(11, 'limpeza', 81, 'concluido', TO_TIMESTAMP('2020-06-11 19:45:00', 'yyyy-mm-dd hh24:mi:ss'));
insert into Intervencao(idIntervencao, tipoIntervencao, QuartoNumQuarto, estadoIntervencao, dataIntervencao)
VALUES(12, 'limpeza', 41, 'concluido', TO_TIMESTAMP('2020-06-15 23:14:00', 'yyyy-mm-dd hh24:mi:ss'));
insert into Intervencao(idIntervencao, tipoIntervencao, QuartoNumQuarto, estadoIntervencao, dataIntervencao)
VALUES(13, 'limpeza', 5, 'concluido', TO_TIMESTAMP('2020-06-21 09:10:00', 'yyyy-mm-dd hh24:mi:ss'));
insert into Intervencao(idIntervencao, tipoIntervencao, QuartoNumQuarto, estadoIntervencao, dataIntervencao)
VALUES(14, 'limpeza', 9, 'concluido', TO_TIMESTAMP('2020-06-19 17:21:00', 'yyyy-mm-dd hh24:mi:ss'));


-- ** tabela Manutencao **
insert into Manutencao(IntervencaoidIntervencaoManutencao, FuncionarioManutencaoFuncionarionif, tipoReparacao)VALUES(1, 253699810, 'Reparacao de Frigobar');
insert into Manutencao(IntervencaoidIntervencaoManutencao, FuncionarioManutencaoFuncionarionif, tipoReparacao)VALUES(2, 253699889, 'Desentupimento da sanita');
insert into Manutencao(IntervencaoidIntervencaoManutencao, FuncionarioManutencaoFuncionarionif, tipoReparacao)VALUES(3, 253699811, 'Reparacap do ar condicionado');
insert into Manutencao(IntervencaoidIntervencaoManutencao, FuncionarioManutencaoFuncionarionif, tipoReparacao)VALUES(4, 253699811, 'Troca das pilhas do comando');
insert into Manutencao(IntervencaoidIntervencaoManutencao, FuncionarioManutencaoFuncionarionif, tipoReparacao)VALUES(5, 253699889, 'Desratizacao');

-- ** tabela Limpeza **
insert into Limpeza(IntervencaoidIntervencaoLimpeza, CamareiraFuncionarionif)VALUES(6, 205314000);
insert into Limpeza(IntervencaoidIntervencaoLimpeza, CamareiraFuncionarionif)VALUES(7, 205314004);
insert into Limpeza(IntervencaoidIntervencaoLimpeza, CamareiraFuncionarionif)VALUES(8, 205314001);
insert into Limpeza(IntervencaoidIntervencaoLimpeza, CamareiraFuncionarionif)VALUES(9, 205314003);
insert into Limpeza(IntervencaoidIntervencaoLimpeza, CamareiraFuncionarionif)VALUES(10, 205314004);
insert into Limpeza(IntervencaoidIntervencaoLimpeza, CamareiraFuncionarionif)VALUES(11, 205314004);
insert into Limpeza(IntervencaoidIntervencaoLimpeza, CamareiraFuncionarionif)VALUES(12, 205314004);
insert into Limpeza(IntervencaoidIntervencaoLimpeza, CamareiraFuncionarionif)VALUES(13, 205314004);
insert into Limpeza(IntervencaoidIntervencaoLimpeza, CamareiraFuncionarionif)VALUES(14, 205314004);



-- ** guardar em DEFINITIVO as altera�?es na base de dados, se a op��o Autocommit do SQL Developer n�o estiver ativada **
-- COMMIT;
