
--Parte I alinea (a)

with intervencaomanutencao AS (
 SELECT DISTINCT interv.funcionarioID,
        ROUND (interv.totalseconds/ (60 * 60), 0) TOTALTIMEINHOURS
   FROM (
         SELECT r.idintervencao,
                r.dataintervencao,
                m.FUNCIONARIOMANUTENCAOFUNCIONARIONIF as funcionarioID,
                ROUND (EXTRACT (DAY FROM systimestamp - r.dataintervencao) * 24 * 60 * 60
                       + EXTRACT (HOUR FROM systimestamp - r.dataintervencao) * 60 * 60
                       + EXTRACT (MINUTE FROM systimestamp - r.dataintervencao) * 60
                       + EXTRACT (SECOND FROM systimestamp - r.dataintervencao)) AS totalseconds
             FROM intervencao r
             JOIN manutencao m 
               ON ( r.idintervencao = m.intervencaoidintervencaomanutencao )
            WHERE r.estadointervencao = 'concluido' 
      ) interv
 WHERE ROUND (interv.totalseconds/ (60 * 60), 0) > 48   
)
Select i.*, m.FUNCIONARIOMANUTENCAOFUNCIONARIONIF
from intervencao i
join manutencao m
on(i.IDINTERVENCAO = m.INTERVENCAOIDINTERVENCAOMANUTENCAO)
join intervencaomanutencao hdi
 ON(m.FUNCIONARIOMANUTENCAOFUNCIONARIONIF = hdi.funcionarioID)
WHERE  i.estadoIntervencao = 'pendente';


--Parte I alinea (b)
SELECT r.dataentrada,
       c.nome,
       CASE
         WHEN q.tipoquarto ='Suite' THEN c.localidade ELSE ' ' 
       END AS "Zona do Pais"    
  FROM reserva r
 INNER JOIN cliente  c
    ON (r.clientenif = c.nif)
 INNER JOIN quarto q
    ON (r.quartonumquarto = q.numquarto)
 WHERE to_char(r.dataentrada, 'MM') IN ( 04, 06 )
 ORDER BY c.nome ASC,
          r.dataentrada DESC;
          
          
--Parte II alinea (a)


with quartosJose AS (
Select c.nome, r.quartonumquarto, r.estado from reserva r
join cliente c
on(c.nif=r.clientenif)
where r.Clientenif = 654635225 and r.estado = 'finalizada' and c.concelho = 'Vila Real'
)
Select c.nome, c.localidade, c.concelho 
from reserva rs
join quartosJose qs
on(rs.quartonumquarto = qs.quartonumquarto)
join cliente c 
ON(rs.clientenif = c.nif)
where rs.estado = 'finalizada' and c.nif <> 654635225;


--Parte II alinea(b)
with intervencoesSeisMeses as(
    select TO_CHAR(i.dataIntervencao, 'YYYY-MM') AnoMes, q.tipoQuarto,q.numquarto, i.idintervencao  from intervencao i
    join quarto q
    on(i.quartonumquarto = q.numquarto)
    where i.dataIntervencao between ADD_MONTHS (SYSDATE,-6) and sysdate and i.tipoIntervencao = 'limpeza' and i.estadoIntervencao = 'concluido'
    group by TO_CHAR(i.dataIntervencao, 'YYYY-MM'), q.tipoQuarto,q.numquarto, i.idintervencao 
    order by 1
), 
mediaocupacao  AS(
    select q.tipoQuarto, avg(r.dataSaida - cast(r.dataEntrada as date)) mediaOcupacao
    from reserva r
    join Quarto q
    on (q.numQuarto = r.quartonumquarto)
    group by q.tipoQuarto
)
SELECT *
FROM(
    Select i.AnoMes, q.tipoQuarto, CamareiraFuncionarioNif, count(*) qtd_intervencoes
    from intervencoesSeisMeses i
    join quarto q
    on(i.numquarto = q.numquarto)
    join limpeza l
    on(i.idIntervencao = l.IntervencaoidintervencaoLimpeza)
    group by i.AnoMes,CamareiraFuncionarioNif, q.tipoquarto) interv 
join mediaocupacao mo
on(interv.tipoquarto = mo.tipoquarto)
WHERE interv.qtd_intervencoes > mo.mediaOcupacao;

--Parte III alinea(a)

with reservas_por_andar as(
    select q.ANDARNUMEROANDAR, q.numQuarto, q.tipoQuarto, count(*) NumeroReservas 
    from Reserva r
    inner join Quarto q 
    on q.numquarto = r.Quartonumquarto
    inner join Andar a
    on q.andarnumeroandar = a.numeroandar
    where r.estado <> 'cancelada' and q.tipoQuarto <> 'Single'
    group by q.ANDARNUMEROANDAR, q.numQuarto, q.tipoQuarto
    order by 1
)
SELECT r.*
FROM reservas_por_andar r
JOIN (
SELECT ANDARNUMEROANDAR, MAX(NumeroReservas) AS NumeroReservas
FROM reservas_por_andar
Group by ANDARNUMEROANDAR) a
ON( r.ANDARNUMEROANDAR = a.ANDARNUMEROANDAR AND r.NumeroReservas = a.NumeroReservas and a.NumeroReservas > 2);




--Parte III alinea(b)
with SuiteClients as (
    Select distinct c.nome, q.tipoquarto, r.dataentrada, r.codReserva from reserva r
    join cliente c
    on (r.clientenif = c.nif)
    join quarto q
    on (r.quartonumquarto = q.numquarto)
    where q.tipoquarto = 'Suite' and r.epocaepocaano = 'Alta' and r.dataEntrada between ADD_MONTHS (SYSDATE,-12) and sysdate  
    and r.dataSaida between ADD_MONTHS (SYSDATE,-12) and sysdate)
select distinct cl.nome, sum(camcons.precoArtigo) 
  from Cliente cl
  join Reserva r
 on r.clientenif = cl.nif
 join Consumo c
 on r.codreserva = c.reservacodreserva
 join camareira_consumo camcons
 on camcons.consumonumidentificacao = c.numidentificacao
 where not exists       
(
select artigo
  from
(
Select cc.artigo, Count(*) artigos 
  from consumo c
            join camareira_consumo cc
            on (c.NUMIDENTIFICACAO = cc.CONSUMONUMIDENTIFICACAO)
            where cc.dataRegisto between ADD_MONTHS (SYSDATE,-24) and sysdate
            group by cc.Artigo
            order by 1 DESC
) x 
 where rownum <=2        
    minus
        Select cc.artigo from consumo c
            join SuiteClients sc
            on (sc.codReserva = c.reservacodreserva)
            join camareira_consumo cc
            on (c.numidentificacao = cc.CONSUMONUMIDENTIFICACAO)
            where cl.nome = sc.nome
)
group by cl.nome
order by 2 DESC;








