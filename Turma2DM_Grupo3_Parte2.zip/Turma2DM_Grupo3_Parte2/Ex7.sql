create or replace function funDisponibilidadeReserva(p_tipoquarto quarto.id_tipo_quarto%type ,p_data reserva.data%type  , p_duracaodias number, p_numeropessoas quarto.lotacaoquarto%type)
return boolean
is 

  v_quartos_validos int;
  v_quartos_reservados int;
  v_quartos_disponiveis int;
 
--  ex_tipo_inexistente exception;
--  ex_data_invalida exception;
--  ex_duracao_null exception;
  
BEGIN
  
 begin
  select count(*) into v_quartos_validos
  from quarto q
  where q.id_tipo_quarto = p_tipoquarto AND q.lotacao_maxima >= p_numeropessoas;
  
  select count(distinct id_quarto) into v_quartos_reservados
  from checkin
  join quarto on id_quarto = quarto.id
  join reserva on id_reserva = reserva.id
  where quarto.id_tipo_quarto = p_tipoquarto AND quarto.lotacao_maxima >= p_numeropessoas
        AND (data_entrada BETWEEN p_data AND (p_data + INTERVAL 'p_duracaodias' DAY) 
        OR data_saida BETWEEN p_data AND (p_data + INTERVAL 'p_duracaodias' DAY));

  v_quartos_disponiveis := v_quartos_validos - v_quartos_reservados;
  end;
  
  if v_ret = 0 then
     return false;
   else
     return true;
   end if;
  
  
END;


