set serveroutput on;
create or replace function fncObterRegistoMensalCamareira(p_mes int , p_ano int default extract(year from sysdate )-1) return sys_refcursor
is    
    c SYS_REFCURSOR;
    ex_mes exception;
    ex_ano exception;
        
begin
if not (p_mes between 1 and 12) then 
    raise ex_mes;
end if;

if  (p_ano > extract(year from sysdate)) then
    raise ex_ano;
end if;  
 
    Open c for
 with camareiras as (
            select c.id, f.nome from funcionario f
            join camareira c on c.id = f.id
                    ),
        
  primeiro_registo as (
                    select c.id, min(lcc.data_registo) prim_reg from linha_conta_consumo lcc
                    join camareira c on c.id = lcc.id_camareira
                    where  extract(month from lcc.data_registo) = p_mes and EXTRACT(year from lcc.data_registo) = p_ano
                    group by c.id
                    ),
                        
  ultimo_registo as ( select c.id , max(lcc.data_registo) ult_reg from linha_conta_consumo lcc
                    join camareira c on c.id = lcc.id_camareira 
                    where EXTRACT(month from lcc.data_registo) = p_mes and EXTRACT(year from lcc.data_registo) = p_ano
                    group by c.id
                    ),
                    
    valor_total as ( select c.id , sum (lcc.quantidade * lcc.preco_unitario) valor_total
                     from linha_conta_consumo lcc
                     join Camareira c on c.id = lcc.id_camareira
                     where EXTRACT(month from lcc.data_registo) = p_mes and EXTRACT(year from lcc.data_registo) = p_ano
                     group by c.id),              
                     
       sem_consumos as ( 
                        select id_camareira id_cam, (select distinct extract(day from last_day(data_registo)) from linha_conta_consumo
                      where extract(month from data_registo) = p_mes) -  count(*) dias_sem_consumo 
                            from (
                                select id_camareira, data_registo
                                    from linha_conta_consumo
                                    where to_char(data_registo, 'mm') = p_mes
                            group by id_camareira, data_registo)
                        group by id_camareira
                        order by 1
                                    ) 
                        
                    
select cam.id, cam.nome, vt.valor_total, pr.prim_reg, ur.ult_reg, sc.dias_sem_consumo  
from camareiras cam
join primeiro_registo pr on cam.id = pr.id
join ultimo_registo ur on cam.id = ur.id
join valor_total vt on vt.id = cam.id
join sem_consumos sc on sc.id_cam = cam.id;

 
 return c;
  
    
exception
when ex_mes then
    RAISE_APPLICATION_ERROR(-20000, 'Mes invalido');
    return null;
    
when ex_ano then
    RAISE_APPLICATION_ERROR(-20001, 'Ano invalido');
    return null;  
   close c;
end;
/

--Teste Ano inv�lido
select fncObterRegistoMensalCamareira(11, 2058) from dual; 

--Teste M�s inv�lido
select fncObterRegistoMensalCamareira(15, 2020) from dual;

--Teste Ano default 
select fncObterRegistoMensalCamareira(11) from dual;

--Teste Todos os par�metros corretos
select fncObterRegistoMensalCamareira(11, 2020) from dual;

