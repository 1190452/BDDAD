create or replace PROCEDURE prcRegistarReserva (p_tipoquarto reserva.id_tipo_quarto%type, p_dataentrada reserva.data_entrada%type, p_datasaida reserva.data_saida%type, p_nrpessoas reserva.nr_pessoas%type, p_idcliente cliente.id%type, p_nome cliente.nome%type, p_nif cliente.nif%type, p_telefone cliente.telefone%type, p_email cliente.email%type)                                    
is
--declaration statements
v_id_reserva reserva.id%type;
v_preco reserva.preco%type;
v_dias int;
ex_tipoquarto_invalido exception;
ex_nrpessoas_invalido exception;
ex_tipoquarto_null exception;
ex_nome_null exception;

begin
--[execution statements]
begin
 if p_tipoquarto is null then
  raise ex_tipoquarto_null;
  end if;
 select q.id_tipo_quarto
 from quarto q
    where p_tipoquarto = q.id_tipo_quarto;
    exception
        when no_data_found then
        raise ex_tipoquarto_invalido;
    end; 
begin
select q.lotacao_maxima
 from quarto q
    where p_nrpessoas < q.lotacao_maxima;
    exception
        when no_data_found then
        raise ex_nrpessoas_invalido;
    end; 
begin
 v_id_reserva := seq_reserva.nextval;
 if p_idcliente is null then
  if nome is null then
   raise ex_nome_null;
  else 
   insert into reserva(id, id_cliente, nome, id_tipo_quarto, data, data_entrada, data_saida, nr_pessoas, preco, id_estado_reserva)
        values(v_id_reserva, null, p_nome, p_tipoquarto, sysdate, p_dataentrada, p_datasaida, p_nrpessoas, null, 1);
  end if;
  else
   insert into reserva(id, id_cliente, nome, id_tipo_quarto, data, data_entrada, data_saida, nr_pessoas, preco, id_estado_reserva)
        values(v_id_reserva, p_idcliente, null, p_tipoquarto, sysdate, p_dataentrada, p_datasaida, p_nrpessoas, v_preco*v_dias, 1);
 end if;
 end;
exception

--[exception handler]


 when ex_tipoquarto_invalido then
  RAISE_APPLICATION_ERROR(-20000, 'O tipo de quarto passado por parametro n�o existe');
    return null;
  when ex_nrpessoas_invalido then
  RAISE_APPLICATION_ERROR(-20001, 'O n�mero de pessoas passado por parametro excede a lota��o m�xima');
    return null;
  when ex_tipoquarto_null then
  RAISE_APPLICATION_ERROR(-20002, 'O tipo de quarto passado por parametro � nulo');
    return null;
  when ex_nome_null then
  RAISE_APPLICATION_ERROR(-20002, 'O nome passado por parametro � nulo');
    return null;

end;
