--ex3
CREATE OR REPLACE TRIGGER trgEpocasNaoSobrepostas
AFTER INSERT or UPDATE ON epoca
DECLARE
counter number;
ex_not_permited exception;
BEGIN
    Select count(*) into counter
        from epoca e
        where exists (select 1 
                        from epoca ep 
                        where (e.data_ini between ep.data_ini and ep.data_fim or e.data_fim between ep.data_ini and ep.data_fim)
                        and ep.rowid <> e.rowid);
    
        
    IF(counter > 0) then
       raise ex_not_permited;
    end if; 
exception
  when ex_not_permited then
    RAISE_APPLICATION_ERROR(-20000, 'Não foi permitido alterar as datas que introduziu');
END;



--Bloco de Testes
insert into epoca(id, nome, data_ini, data_fim) values(5,'Lalala', to_date('2020-12-24', 'yyyy-mm-dd'), to_date('2020-12-25', 'yyyy-mm-dd'));
Update epoca e set data_ini = to_date('2020-01-01', 'yyyy-mm-dd'), data_fim  = to_date('2020-12-31', 'yyyy-mm-dd') where e.id = 4;
Update epoca e set data_ini = to_date('2020-11-01', 'yyyy-mm-dd'), data_fim  = to_date('2020-12-31', 'yyyy-mm-dd') where e.id = 4;

--visualizar as alterações
select * from epoca;

