--ex2
create or replace procedure prcCheckOut(idReserva reserva.id%type)
IS
dataS_reserva reserva.data_saida%type;
idC_reserva reserva.id_cliente%type;
preco_reserva reserva.preco%type;
extra_reserva reserva.custo_extra%type;
consumo_cost linha_conta_consumo.preco_unitario%type;
fatura_numero fatura.numero%type;
id_fatura fatura.id%type;
idContaConsumo linha_conta_consumo.id_conta_consumo%type;
rowlinha linha_conta_consumo%rowtype;
ex_reserva_inexistente exception;

begin
    begin
    Select r.data_saida, r.id_cliente, r.preco, r.custo_extra into  dataS_reserva, idC_reserva, preco_reserva, extra_reserva 
    from reserva r
    where idReserva = r.id;
    exception
        when no_data_found then
        raise ex_reserva_inexistente;
    end; 
    begin
        Select lc.id_conta_consumo, SUM(lc.preco_unitario*lc.quantidade) 
         into idContaConsumo, consumo_cost 
         from linha_conta_consumo lc  
         join conta_consumo c
           on c.id = lc.id_conta_consumo and c.id_reserva = idReserva
           group by lc.id_conta_consumo;  
           
        Select lc.* into rowlinha
         from linha_conta_consumo lc  
         join conta_consumo c
        on c.id = lc.id_conta_consumo and c.id_reserva = idReserva;
    end;
    begin
    select round(dbms_random.value(1,10000)) into id_fatura from dual;
    insert into checkout(id_reserva, data, observacoes, valor_extra) 
                values (idReserva, dataS_reserva, 'sem observaçoes', nvl(extra_reserva,0));
                
    insert into fatura(id, numero,data, id_cliente, id_reserva, valor_faturado_reserva, valor_faturado_consumo) 
                values (id_fatura, seq_fatura.nextval, dataS_reserva, idC_reserva, idReserva, (preco_reserva + nvl(extra_reserva,0)), consumo_cost);
                
    insert into linha_fatura(id_fatura, linha, id_conta_consumo, linha_conta_consumo, valor_consumo)
                values(id_fatura,1,idContaConsumo,rowlinha.linha,consumo_cost);
                
    end;
exception
  when ex_reserva_inexistente then
    RAISE_APPLICATION_ERROR(-20000, 'A reserva não existe');
end;
/

--Bloco de Testes
begin
  prcCheckOut(1173);  
end;
/

begin
  prcCheckOut(5445);  
end;
/

--verificar os inserts
select * from fatura;
select * from checkout;
select * from linha_fatura;

--verificar os produtos consumidos associados a reserva
select * from linha_conta_consumo lc
join conta_consumo c
on c.id = lc.id_conta_consumo
WHERE c.id_reserva= 1173;

select * from reserva
where id = 1173;

--delete aos inserts feitos
delete from linha_fatura
where id_fatura = 2264;

delete from fatura
where id = 2264;

delete from checkout
where id_reserva = 1173;

