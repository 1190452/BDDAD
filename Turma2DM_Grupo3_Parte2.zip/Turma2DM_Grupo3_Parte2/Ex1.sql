--ex1
create or replace function fncGetQuartoReserva(r_idreserva reserva.id%type) return quarto.nr_quarto%type
is
  idTipoQuarto tipo_quarto.id%type;
  dataEntrada reserva.data_entrada%type;
  dataSaida reserva.data_saida%type;
  estadoReserva reserva.id_estado_reserva%type;
  nrQuarto quarto.id%type;
  idAndarQuarto quarto.id_andar%type;
  diasOcup int;
  has_checkin integer; 
  ex_reserva_inexistente exception;
  ex_reserva_null exception;
  ex_reserva_com_quarto exception;
  ex_reserva_estado exception;
begin
 if r_idreserva is null then 
    raise  ex_reserva_null;   
 end if;
    begin 
        Select count(1)
          into has_checkin
          from checkin c
         where c.id_reserva= r_idreserva;
         
        
        if   has_checkin  > 0 then
                raise ex_reserva_com_quarto;
        end if;    
    end;
    begin
        Select r.id_tipo_quarto, r.data_entrada, r.data_saida, r.id_estado_reserva 
          into idTipoQuarto, dataEntrada, dataSaida, estadoReserva
          from reserva r
         where r.id = r_idreserva; 
     if estadoReserva =  5 then
         raise ex_reserva_estado;
     end if;
    exception
        when no_data_found then
        raise ex_reserva_inexistente;
    end; 
    begin
    with quartosDisponiveis as ((Select q.nr_quarto, q.id, q.id_andar
        from quarto q 
        where q.id_tipo_quarto = idTipoQuarto) 
        
        minus 
        
        (Select q.nr_quarto, q.id, q.id_andar
        from quarto q 
        join checkin c
        on (c.id_quarto = q.id)
        join reserva r
        on c.id_reserva = r.id
        where (r.data_entrada between dataEntrada and dataSaida) and  (r.data_saida between dataEntrada and dataSaida) and (q.id_tipo_quarto = idTipoQuarto))), 
        
        nr_reservas as (
            select c.id_quarto, count(r.data_saida - r.data_entrada) nr_tempoOcup
              from checkin c 
              join reserva r
              on(c.id_reserva = r.id ) 
              where r.data_entrada between ADD_MONTHS(sysdate,-24) and sysdate and (r.id_estado_reserva = 5) 
              group by c.id_quarto
        )
        
    Select qd.nr_quarto,qd.id_andar, nr.nr_tempoOcup into nrQuarto, idAndarQuarto, diasOcup
      from quartosDisponiveis qd
        join nr_reservas nr
        on nr.id_quarto = qd.id
      where rownum <=1
      order by 3, 2 DESC;
    end;
    
    return nrQuarto;
exception
  when ex_reserva_inexistente then
  RAISE_APPLICATION_ERROR(-20000, 'A reserva passada por parametro não existe');
    return null;
  when ex_reserva_null then
  RAISE_APPLICATION_ERROR(-20001, 'A reserva passada por parametro e nula');
    return null;
  when ex_reserva_com_quarto then
  RAISE_APPLICATION_ERROR(-20002, 'A reserva já possui um quarto associado');
    return null;
  when ex_reserva_estado then
  RAISE_APPLICATION_ERROR(-20003, 'O estado da reserva não é adequado');
    return null;   
end;
/


--Bloco de Testes
Select fncGetQuartoReserva(1) from dual;

declare
  v_count quarto.nr_quarto%type;
begin
  v_count := fncGetQuartoReserva(1);
 
end;
/


declare
  v_count quarto.nr_quarto%type;
begin
  v_count := fncGetQuartoReserva(5653);
 
end;
/

declare
  v_count quarto.nr_quarto%type;
begin
  v_count := fncGetQuartoReserva(null);
 
end;
/


declare
  v_count quarto.nr_quarto%type;
begin
  v_count := fncGetQuartoReserva(34);
 
end;
/

declare
  v_count quarto.nr_quarto%type;
begin
  v_count := fncGetQuartoReserva(211);
end;
/




