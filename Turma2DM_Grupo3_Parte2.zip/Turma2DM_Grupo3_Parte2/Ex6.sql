create or replace trigger trgCorrigirAlteracaoBonus
before update 
on camareira
for each row
declare ex_menos_bonus exception; ex_mais_bonus exception;
begin
    if (:new.bonus) > (:old.bonus + (:old.bonus * 0.5))  then
        raise ex_mais_bonus;
    end if;
    
    if (:new.bonus) < :old.bonus  then
        raise ex_menos_bonus;
    end if;    
exception
    when ex_menos_bonus then  raise_application_error(-20000,'B�nus n�o pode ser diminuido');
    when ex_mais_bonus then raise_application_error(-20001,'O aumento de b�nus n�o pode ser superior a 50%');

end;
/


--Teste diminuir b�nus
begin
update camareira
    set bonus = bonus -1;
end;


--Teste aumentar em mais de 50% o b�nus
begin
update camareira
    set bonus = bonus + bonus * 0.6;
end;

--Teste em que o b�nus � aumentado menos de 50%
begin 
update camareira
    set bonus = bonus + bonus * 0.4;
end;






  