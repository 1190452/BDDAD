--5)
alter table camareira add (bonus FLOAT(10));
alter table camareira drop column bonus;
select * from camareira;
create or replace procedure prcAtualizarBonusCamareiras(p_mes int , p_ano int default extract(year from sysdate))
is
    ex_mes exception;
    ex_ano exception;
    cursor c is select c.id, sum (lcc.quantidade * lcc.preco_unitario) valor_total
                                        from linha_conta_consumo lcc
                                        join Camareira c on c.id = lcc.id_camareira
                                        where  p_mes = extract(month from lcc.data_registo) and  p_ano= extract(year from lcc.data_registo)
                                        group by c.id
                                        order by 1;
    r c%rowtype;                                    
    
begin

if not (p_mes between 1 and 12) then 
    raise ex_mes;
end if;

if  (p_ano > extract(year from sysdate)) then
    raise ex_ano;
end if;

  open c;
  loop
    fetch c into r;
    
    exit when c%notfound;
  begin       
    if (r.valor_total  > 1000) then 
    UPDATE camareira
        set bonus =  r.valor_total * 0.15
    where id = r.id;    
  end if;
  
  if (r.valor_total <= 1000 and r.valor_total >=500) then
    update camareira
        set bonus =  r.valor_total*0.10
    where id = r.id;    
  end if;
  
   if (r.valor_total < 500 and r.valor_total >100) then
    update camareira
        set bonus =  r.valor_total*0.05
    where id = r.id;    
  end if;
  
   if (r.valor_total <=100) then
    update camareira
        set bonus =   r.valor_total*0
    where id = r.id;    
  end if;
  exception
  when others then null;
  end;
  end loop;
  close c;
  
                                      
                  
exception
when ex_mes then
    RAISE_APPLICATION_ERROR(-20000, 'M�s inv�lido');
when ex_ano then
    RAISE_APPLICATION_ERROR(-20001, 'Ano inv�lido');  
    


end;
/


--Teste com par�metros corretos
begin
 prcAtualizarBonusCamareiras(05,2020);
end; 

--Teste com o ano default
begin
 prcAtualizarBonusCamareiras(05);
end;

--Teste com m�s inv�lido
begin
 prcAtualizarBonusCamareiras(15,2020);
end;

--Teste com ano inv�lido
begin
 prcAtualizarBonusCamareiras(11,2024);
end;

--comando para desabilitar o trigger, de modo a poder executar o procedimento m�ltiplas vezes
alter trigger trgCorrigirAlteracaoBonus disable;

--anular a desabilita��o anterior
alter trigger trgCorrigirAlteracaoBonus enable;

update camareira set bonus = null;

select * from camareira;